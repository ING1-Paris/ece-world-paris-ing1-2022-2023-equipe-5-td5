#include "header.h"


//SSPG charg� de l'initialisation des fonctions relatives � allegro
void initAllegro()
{

    srand(time(NULL)); //on initialise la fonction random (utile pour plus tard)
    allegro_init();    //initialisation allegro
    install_keyboard(); //on permet l'utilisation du clavier
    install_mouse();  //on permet l'utilisation de la souris
    set_color_depth(desktop_color_depth());    //initialisation de la palette de couleur


    //on initialise les fonctions de son
    if (install_sound(DIGI_AUTODETECT, MIDI_NONE, 0) != 0) {
        printf("Error initialising sound: %s\n", allegro_error);
        exit(1);
    }

    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,SCREEN_W,SCREEN_H,0,0))!=0)      //param�tres fen�tre
    {
        //probl�me avec fen�tre allegro
        allegro_message("Pb de mode graphique");
        allegro_exit();                                             //fermeture allegro
        exit(EXIT_FAILURE);                                         //sortie forc�e du programme
    }

    show_mouse(screen); //on affiche la souris � l'�cran




}

t_partie initPartie()
{
    t_partie partie;

    for(int i=0; i<2; i++)
    {
        partie.playerBase[i] = initJoueur();
    }

    partie.jeux= initMinijeux();


    return t_partie;
}

t_joueur initJoueur()
{
    t_joueur joueur;

    joueur.score=0;
    joueur.tickets=5;

    return t_joueur;
}

t_minigame initMinijeux()
{
    t_minigame miniJeux[4];

    miniJeux[0].titre = "Peche aux canards";

    miniJeux[1].titre = "Taupe-la!";

    miniJeux[2].titre = "Tir au ballons";

    miniJeux[3].titre = "Paris hippiques";


    return miniJeux;
}


t_banqueImage loadBanqueImage()
{
    t_banqueImage image;




    return image;
}


t_banquePolice loadBanquePolices()
{
    t_banquePolice police;


    return police;
}



