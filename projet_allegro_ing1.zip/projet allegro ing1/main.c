#include "header.h"


int main()
{

    t_banqueImage banqueImage;
    t_banquePolice banquePolice;
    t_partie partie;


    initAllegro(); //on initialise tout le n�cessaire en rapport avec allegro

    banqueImage = loadBanqueImage();
    banquePolice = loadBanquePolices();

    while(!key[KEY_ESC])
    {
        //main menu
    }


    return 0;
}

END_OF_MAIN()
