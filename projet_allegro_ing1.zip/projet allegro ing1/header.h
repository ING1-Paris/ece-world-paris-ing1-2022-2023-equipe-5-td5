#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>
#include <math.h>


#define SCREEN_W 1500 //largeur de la fen�tre allegro
#define SCREEN_H 1000  //hauteur de la fen�tre allegro

///---------------------DEV NOTES-----------------------------///

/*

Pour le d�placement sur la carte, faire un timer qui check tout les x temps pour checker si on appuie bien sur les fl�ches
ou juste faire par appui de fl�che un par un en checkant qu'on d�sappuie sur le bouton


On fait deux personnages sur la meme case qui ne bougent pas, on �co sur les animations/sprites

Pour la carte, 2D vue de dessue avec des sprites sur plusieurs X/Y pour les batiments d'attraction
sprites des bat en 4x4 cases

Faire la carte avec un tab[x][y] avec des draw rect de couleur pour les cases


sur la carte, faire un bouton menu pour afficher les stats et de quitter (faire une sauvegarde?)
faire aussi un bouton gris� pour lancer l'attraction si on est pas devant ( faire des cases sp�)

sur le menu, faire une case pour les r�gles/cr�dits, une pour lancer une partie

TICKETS: cout/att = 1, reward/win =2

*/

///--------------------STRUCTURES---------------------------///

typedef struct partie //structure principale charg�e de stocker toutes les infos de la partie
{
    //tab de 2 joueurs
    t_joueur playerBase[2];
    //tab de 4 minigame
    t_minigame jeux[4];

}t_partie;


typedef struct joueur //structure charg�e de stocker les informations d'un joueur
{
    //nom
    char name[20];
    //nombre de tickets
    int tickets;
    //score
    int score;
    //id ordre de jeu
}t_joueur;


typedef struct minigame //structure charg�e de stocker les informations d'une attraction
{
    //nom
    char titre[20];
    //difficul�es
    int difficulty;
    //specs

    //tab de cases prises par le bat
    int coordBat[2][2];
    //coord de la case permettant de lancer le minijeu
    int coordPlay[2];

}t_minigame;



typedef struct banqueImage //  Structure utilis�e pour stocker les images utilis�es pour le projet
{
    BITMAP * fondMenu;
    BITMAP * joueur;
    BITMAP * batMinigame[4];


}t_banqueImage;


typedef struct banquePolice //  Structure utilis�e pour stocker les polices utilis�es pour le projet
{

    //FONT *

}t_banquePolice;




///--------------------- SOUS-PROGS -----------------------///

//-------- Syst�me -------//
void initAllegro(); //SSPG charg� d'initialiser les fonctions d'allegro
t_banqueImage loadBanqueImage(); //SSPG charg� d'initaliser et de charger les diff�rentes images dans la structure de stockage
t_banquePolice loadBanquePolices();//idem mais pour les polices d'"critures utilis�es


//---------Menu-----------//
void menuPrincipal(t_partie partie, t_banqueImage image, t_banquePolice police);



#endif // HEADER_H_INCLUDED
